// SimpleMath.cs

public class SimpleMath
{
	public static int Add(int x, int y)
	{
		return x + y;
	}
	public static int Multiply(int x, int y)
	{
		return x * y;
	}
}