// SimpleMath.cs

public class SimpleMath
{
	public static int Add(int x, int y)
	{
		return x + y;
	}
	public static int Multiply(int x, int y)
	{
		return x * y;
	}
	public static int Divide(int x, int y)
	{
		return x / y;
	}
	public static int Subtract(int x, int y)
	{
		return x - y;
	}
	public static double Add(double x, double y)
	{
		return x + y;
	}
	public static double Multiply(double x, double y)
	{
		return x * y;
	}
	public static double Divide(double x, double y)
	{
		return x / y;
	}
	public static double Subtract(double x, double y)
	{
		return x - y;
	}
}