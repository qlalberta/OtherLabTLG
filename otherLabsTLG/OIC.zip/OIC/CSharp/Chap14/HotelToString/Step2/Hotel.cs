// Hotel.cs � Step 2

using System;

public class Hotel
{
   private string city;
	private string name;
	public Hotel(string city, string name)
	{
		this.city = city;
		this.name = name;
	}
	//override public string ToString()
	//{
	//	return city + " " + name;
	//}
}