// Seven.cs

using System;

public class Seven
{
	public static int Main(string[] args)
	{
       char seven = '7';
       short number;
       number = seven;
       Console.WriteLine("seven = " + seven);
       Console.WriteLine("number = " + number);
	    return 0;
	}
}
