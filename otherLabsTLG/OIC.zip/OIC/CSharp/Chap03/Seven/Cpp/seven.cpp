// seven.cpp

#include <iostream>
using namespace std;

int main()	
{
	char seven = '7';
	short number;
	number = seven;
	cout << "seven = " << seven << endl;
	cout << "number = " << number << endl;
	return 0;
}

