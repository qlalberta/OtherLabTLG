// SpecialFloat.cs

using System;

public class SpecialFloat
{
	public static int Main(string[] args)
   {
		Console.WriteLine("1.0/0.0 = " + 1.0/0.0);
		Console.WriteLine("0.0/0.0 = " + 0.0/0.0);
		return 0;
	}
}

