﻿namespace ListBoxDemo
{
   partial class Form1
   {
      /// <summary>
      /// Required designer variable.
      /// </summary>
      private System.ComponentModel.IContainer components;

      /// <summary>
      /// Clean up any resources being used.
      /// </summary>
      /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
      protected override void Dispose(bool disposing)
      {
         if (disposing && (components != null))
         {
            components.Dispose();
         }
         base.Dispose(disposing);
      }

      #region Windows Form Designer generated code

      /// <summary>
      /// Required method for Designer support - do not modify
      /// the contents of this method with the code editor.
      /// </summary>
      private void InitializeComponent()
      {
         this.cmdRemove = new System.Windows.Forms.Button();
         this.cmdAdd = new System.Windows.Forms.Button();
         this.listBox1 = new System.Windows.Forms.ListBox();
         this.txtString = new System.Windows.Forms.TextBox();
         this.label1 = new System.Windows.Forms.Label();
         this.SuspendLayout();
         // 
         // cmdRemove
         // 
         this.cmdRemove.Location = new System.Drawing.Point(207, 59);
         this.cmdRemove.Name = "cmdRemove";
         this.cmdRemove.Size = new System.Drawing.Size(75, 23);
         this.cmdRemove.TabIndex = 19;
         this.cmdRemove.Text = "Remove";
         this.cmdRemove.Click += new System.EventHandler(this.cmdRemove_Click);
         // 
         // cmdAdd
         // 
         this.cmdAdd.Location = new System.Drawing.Point(207, 19);
         this.cmdAdd.Name = "cmdAdd";
         this.cmdAdd.Size = new System.Drawing.Size(75, 23);
         this.cmdAdd.TabIndex = 18;
         this.cmdAdd.Text = "Add";
         this.cmdAdd.Click += new System.EventHandler(this.cmdAdd_Click);
         // 
         // listBox1
         // 
         this.listBox1.Location = new System.Drawing.Point(23, 59);
         this.listBox1.Name = "listBox1";
         this.listBox1.Size = new System.Drawing.Size(160, 95);
         this.listBox1.TabIndex = 17;
         this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
         // 
         // txtString
         // 
         this.txtString.Location = new System.Drawing.Point(79, 19);
         this.txtString.Name = "txtString";
         this.txtString.Size = new System.Drawing.Size(100, 20);
         this.txtString.TabIndex = 16;
         // 
         // label1
         // 
         this.label1.Location = new System.Drawing.Point(23, 19);
         this.label1.Name = "label1";
         this.label1.Size = new System.Drawing.Size(48, 23);
         this.label1.TabIndex = 15;
         this.label1.Text = "String";
         // 
         // Form1
         // 
         this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
         this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
         this.ClientSize = new System.Drawing.Size(310, 177);
         this.Controls.Add(this.cmdRemove);
         this.Controls.Add(this.cmdAdd);
         this.Controls.Add(this.listBox1);
         this.Controls.Add(this.txtString);
         this.Controls.Add(this.label1);
         this.Name = "Form1";
         this.Text = "List Box Demonstration";
         this.ResumeLayout(false);
         this.PerformLayout();

      }

      #endregion

      private System.Windows.Forms.Button cmdRemove;
      private System.Windows.Forms.Button cmdAdd;
      private System.Windows.Forms.ListBox listBox1;
      private System.Windows.Forms.TextBox txtString;
      private System.Windows.Forms.Label label1;
   }
}

