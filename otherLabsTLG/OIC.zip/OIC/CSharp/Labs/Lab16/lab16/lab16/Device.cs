﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//class device
//{
//    string Device;
//    private int MotorId;
//    decimal Temp;
//    decimal Speed;
//    Boolean Power;
    
//    public Device(int Motorid, string devicename, decimal temp, decimal speed, Boolean power )
//    {
//        this.MotorId = Motorid;
//    }
//}

