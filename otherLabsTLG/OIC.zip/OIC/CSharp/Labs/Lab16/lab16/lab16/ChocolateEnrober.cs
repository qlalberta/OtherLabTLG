﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// derived class ChocalateEnrober
//class ChocolateEnrober: Device
//{
    //string Device;
    //private int MotorId;
    //decimal Temp;
    //decimal Speed;
    //Boolean Power;
//}

