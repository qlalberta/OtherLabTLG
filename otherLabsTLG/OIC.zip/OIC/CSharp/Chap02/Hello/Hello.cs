// Hello.cs

class Hello
{
    public static int Main(string[] args)
    {
        System.Console.WriteLine("Hello, World");
        return 0;
    }
}
