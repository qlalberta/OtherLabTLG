// Hello3.cs

using System;

class Hello
{
    public static void Main()
    {
        Console.WriteLine("Hello, World");
		Console.WriteLine("My name is Bob");
		Console.WriteLine("Goodbye");
    }
}
