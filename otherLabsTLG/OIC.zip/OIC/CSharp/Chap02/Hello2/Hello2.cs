// Hello2.cs
//
// This version illustrates "using"

using System;

class Hello
{
    public static void Main()
    {
        Console.WriteLine("Hello, World");
    }
}
