﻿class SimpleMath
{
	public static long OneK(long x)
	{
		return 1024 * x;
	}
}

