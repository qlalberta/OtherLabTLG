// Account.cs

public class Account
{
	public int Id;
	public decimal Balance;
}